package com.data_flair.storm.multiplestream;

import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

public class StormMultipleStreamBolt extends BaseRichBolt {

	private static final long serialVersionUID = 1L;
	int count = 0;
	OutputCollector collector = null;

	public void execute(Tuple input) {

		// fetched the field “site” from input tuple.
		String test = input.getStringByField("data");
		//test="a,b,c"
		String[] records = test.split(",");
		// print the value of field “site” on console.
		System.out.println("Name of input site is : " + test);

		collector.emit("stream1", new Values(records[0], records[1]));
		collector.emit("stream2", new Values(records[1], records[2]));
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream("stream1", new Fields("a", "b"));
		declarer.declareStream("stream2", new Fields("b", "c"));
	}

	public void prepare(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		this.collector = collector;
	}
}
