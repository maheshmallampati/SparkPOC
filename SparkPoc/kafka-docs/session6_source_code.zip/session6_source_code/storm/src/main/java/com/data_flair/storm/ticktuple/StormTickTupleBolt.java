package com.data_flair.storm.ticktuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import backtype.storm.Config;
import backtype.storm.Constants;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

public class StormTickTupleBolt extends BaseRichBolt {

	private static final long serialVersionUID = 1L;
	int count = 0;
	OutputCollector collector = null;

	@Override
	public Map<String, Object> getComponentConfiguration() {
		Config config = new Config();
		config.put(Config.TOPOLOGY_TICK_TUPLE_FREQ_SECS, 1);
		return config;
	}

	private static boolean isTickTuple(Tuple tuple) {
		System.out.println(tuple.getSourceStreamId() + " ================== ");
		return tuple.getSourceComponent().equals(Constants.SYSTEM_COMPONENT_ID) && tuple.getSourceStreamId().equals(Constants.SYSTEM_TICK_STREAM_ID);
	}

	public List<String> datas = new ArrayList<String>();
	public void execute(Tuple input) {
		if (isTickTuple(input)) {
			System.out.println("Tick Tuple recieved ============ " + input);
			// flushing datas list
			System.out.println(datas);
			datas.clear();

		} else {
			// fetched the field “data” from input tuple.
			try {

				String test = input.getStringByField("data");
				datas.add(test);
				System.out.println("Name of input site is : " + test);
			} catch (Exception exception) {

			}
		}
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {

	}

	public void prepare(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		this.collector = collector;
	}
}
