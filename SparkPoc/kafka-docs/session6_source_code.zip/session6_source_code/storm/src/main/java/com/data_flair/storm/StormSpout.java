package com.data_flair.storm;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import backtype.storm.spout.SpoutOutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichSpout;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Values;

public class StormSpout extends BaseRichSpout {
	private static final long serialVersionUID = 1L;
	private SpoutOutputCollector spoutOutputCollector;
	private static final Map<Integer, String> map = new HashMap<Integer, String>();
	private Map<String,Object> recordCache = new HashMap<String, Object>();
	static {
		map.put(0, "google");
		map.put(1, "facebook");
		map.put(2, "twitter");
		map.put(3, "youtube");
		map.put(4, "linkedin");
	}

	public void open(Map conf, TopologyContext context,
			SpoutOutputCollector spoutOutputCollector) {
		// Open the spout
		this.spoutOutputCollector = spoutOutputCollector;

	}

	public void nextTuple() {
		// Storm cluster repeatedly call this method to emit the continuous //
		// stream of tuples.
		final Random rand = new Random();
		// generate the random number from 0 to 4.
		int randomNumber = rand.nextInt(5);

		String messageId = UUID.randomUUID().toString();
		recordCache.put(messageId, map.get(randomNumber));


		// emit method
		spoutOutputCollector.emit(new Values(map.get(randomNumber)), messageId);

	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		// emit the field site.
		declarer.declare(new Fields("site"));
	}

	@Override
    public void ack(Object msgId) {
		System.out.println("ACK Recieved : "+msgId);
		recordCache.remove(msgId);

    }

	@Override
    public void fail(Object msgId) {
		System.out.println("Record failed " + msgId);
		spoutOutputCollector.emit(new Values(recordCache.get(msgId.toString())), msgId);
		System.out.println("Emit the message again");
    }

}
