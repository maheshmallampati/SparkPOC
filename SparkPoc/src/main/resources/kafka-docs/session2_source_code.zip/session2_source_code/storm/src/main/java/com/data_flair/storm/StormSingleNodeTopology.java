package com.data_flair.storm;

import backtype.storm.Config;
import backtype.storm.StormSubmitter;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;

public class StormSingleNodeTopology {
	public static void main(String[] args) {
		TopologyBuilder builder = new TopologyBuilder();
		builder.setSpout("StormSpout", new StormSpout(), 2);
		builder.setBolt("StormBolt", new StormBolt(), 2).shuffleGrouping("StormSpout");

		Config conf = new Config();
		conf.setNumWorkers(3);
		try {
		StormSubmitter.submitTopology(args[0], conf, builder.createTopology());
		}catch(AlreadyAliveException alreadyAliveException) {
			System.out.println(alreadyAliveException);
		} catch (InvalidTopologyException invalidTopologyException) {
			System.out.println(invalidTopologyException);
		}
	}
}
