package com.data_flair.storm;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;


public class StormTopology {
	public static void main(String[] args) throws AlreadyAliveException,
			InvalidTopologyException {
		TopologyBuilder builder = new TopologyBuilder();
		// set the spout class
		builder.setSpout("StormSpout", new StormSpout(), 2);

		// set the bolt class
		builder.setBolt("StormBolt", new StormBolt(), 2).shuffleGrouping("StormSpout");

		//builder.setBolt("StormBolt", new StormBolt(), 2).fieldsGrouping("StormSpout", new Fields("site"));
		//builder.setBolt("StormBolt", new StormBolt(), 2).globalGrouping("StormSpout");
		//builder.setBolt("StormBolt", new StormBolt(), 2).allGrouping("StormSpout");

		//builder.setBolt("StormBolt", new StormBolt(), 2).customGrouping("StormSpout", new CategoryGrouping());

		Config conf = new Config();
		conf.setDebug(false);
		// create an instance of LocalCluster class for
		// executing topology in local mode.
		LocalCluster cluster = new LocalCluster();

		// StormTopolgy is the name of submitted topology.
		cluster.submitTopology("StormToplogy", conf,
				builder.createTopology());
		try {
			Thread.sleep(10000);
		} catch (Exception exception) {
			System.out.println("Thread interrupted exception : " + exception);
		}
		// kill the LearningStormTopology
		cluster.killTopology("StormToplogy");
		// shutdown the storm test cluster
		cluster.shutdown();

	}
}
