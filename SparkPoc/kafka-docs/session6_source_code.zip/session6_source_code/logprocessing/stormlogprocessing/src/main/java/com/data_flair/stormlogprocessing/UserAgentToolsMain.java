package com.data_flair.stormlogprocessing;

public class UserAgentToolsMain {

	public static void main(String[] args) {
		String userAgent = "Mozilla/5.0 (Windows NT 6.0; WOW64; rv:2.0.1) Gecko/20100101 Firefox/4.0.1";
		String os = new UserAgentTools().getOS(userAgent)[2];
		String browser = new UserAgentTools().getBrowser(userAgent)[2];

		System.out.println("Operating System : " + os);
		System.out.println("Browser : " + browser);
	}

}
