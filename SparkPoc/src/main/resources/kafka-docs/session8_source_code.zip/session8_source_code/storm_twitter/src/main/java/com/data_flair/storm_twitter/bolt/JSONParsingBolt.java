package com.data_flair.storm_twitter.bolt;

import java.io.Serializable;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;

public class JSONParsingBolt extends BaseRichBolt implements Serializable{

	private OutputCollector collector;

	public void prepare(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		this.collector = collector;

	}

	public void execute(Tuple input) {
		try {
			String tweet = input.getString(0);
			Map<String, Object> map = new ObjectMapper().readValue(tweet, Map.class);
			collector.emit("stream1",new Values(tweet));
			collector.emit("stream2",new Values(map.get("text")));
			this.collector.ack(input);
		} catch (Exception exception) {
			exception.printStackTrace();
			this.collector.fail(input);
		}
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {
		declarer.declareStream("stream1",new Fields("tweet"));
		declarer.declareStream("stream2",new Fields("text"));
	}

}
