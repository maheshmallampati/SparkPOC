package com.data_flair.storm.hook;

import java.util.Map;

import backtype.storm.Config;
import backtype.storm.Constants;
import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Tuple;

public class StormBolt extends BaseRichBolt {

	private static final long serialVersionUID = 1L;
	int count = 0;
	OutputCollector collector = null;

	public void execute(Tuple input) {

		// fetched the field “data” from input tuple.
		try {
			String test = input.getStringByField("data");
			System.out.println("Name of input site is : " + test);
		} catch (Exception exception) {

		}
	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {

	}

	public void prepare(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		this.collector = collector;
	}
}
