package com.dataflair.kafka.twitter;

import java.io.IOException;
import java.net.URI;
import java.util.EnumSet;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

import kafka.consumer.ConsumerIterator;
import kafka.consumer.KafkaStream;
import kafka.javaapi.consumer.ConsumerConnector;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataOutputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.hdfs.client.HdfsDataOutputStream;
import org.apache.hadoop.hdfs.client.HdfsDataOutputStream.SyncFlag;
/**
 * This class recieved the byte[] data and convert into string and print on console
 * This is the one consumer instance in a group
 * @author centos
 *
 */
public class ConsumerInstance implements Runnable {
		private KafkaStream stream;
		private int threadNumber;
		private ConsumerConnector consumer;
		private transient FileSystem fs;
		private transient FSDataOutputStream out;
		private Configuration hdfsConfig = new Configuration();
		private AtomicLong ai = new AtomicLong(0);
		public ConsumerInstance(KafkaStream stream, int threadNumber, ConsumerConnector consumer) throws IOException {
			this.threadNumber = threadNumber;
			this.stream = stream;
			this.consumer =consumer;
			this.fs = FileSystem.get(URI.create("hdfs://127.0.0.1:8020"), hdfsConfig);
			this.out = this.fs.create(new Path("/kafka-hdfs/","pqr-"+System.currentTimeMillis()));
		}

		public void run() {

			ConsumerIterator<byte[], byte[]> it = stream.iterator();
			// Iterate over the list
			while (it.hasNext()) {
					// print the data on console
					try {
						out.write(it.next().message());
						ai.incrementAndGet();
						if(ai.get()%100==0) {
							this.out.hsync();
						}
						if(ai.get()%20000==0) {
							try {
							this.out.close();
							}catch(Exception exception) {
								exception.printStackTrace();
							}
							this.out = this.fs.create(new Path("/kafka-hdfs/","pqr-"+System.currentTimeMillis()));
						}
						System.out.println("Thread " + threadNumber + ": "
								+ new String(it.next().message()));
					} catch (Exception e) {
						e.printStackTrace();
					}

			}
			System.out.println("Shutting down Thread: " + threadNumber);
		}
}
