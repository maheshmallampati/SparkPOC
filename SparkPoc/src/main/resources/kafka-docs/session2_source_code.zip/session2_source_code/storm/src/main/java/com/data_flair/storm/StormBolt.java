package com.data_flair.storm;

import java.util.Map;

import backtype.storm.task.OutputCollector;
import backtype.storm.task.TopologyContext;
import backtype.storm.topology.OutputFieldsDeclarer;
import backtype.storm.topology.base.BaseRichBolt;
import backtype.storm.tuple.Fields;
import backtype.storm.tuple.Tuple;
import backtype.storm.tuple.Values;


public class StormBolt extends BaseRichBolt{

	private static final long serialVersionUID = 1L;
	int count = 0;
	OutputCollector collector = null;
	public void execute(Tuple input) {

		// fetched the field “site” from input tuple.
		String test = input.getStringByField("site");
		// print the value of field “site” on console.
		System.out.println("Name of input site is : " + test);

/*		if(count%100 == 0) {
			collector.fail(input);
		} else {
			count++;*/
			collector.ack(input);
		/*}*/

	}

	public void declareOutputFields(OutputFieldsDeclarer declarer) {

	}

	public void prepare(Map stormConf, TopologyContext context,
			OutputCollector collector) {
		this.collector = collector;
	}
}
