package com.data_flair.storm.multiplestream;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.generated.AlreadyAliveException;
import backtype.storm.generated.InvalidTopologyException;
import backtype.storm.topology.TopologyBuilder;
import backtype.storm.tuple.Fields;

public class StormMultiStreamTopology {
	public static void main(String[] args) throws AlreadyAliveException,
			InvalidTopologyException {
		TopologyBuilder builder = new TopologyBuilder();
		// set the spout class
		builder.setSpout("StormSpout", new StormMultipleStreamSpout(), 1);

		// set the bolt class
		builder.setBolt("StormBolt", new StormMultipleStreamBolt(), 1).shuffleGrouping(
				"StormSpout");

		//builder.setBolt("StormBolt", new StormMultipleStreamBolt(), 1).fieldsGrouping("StormSpout", new Fields("country"));

		builder.setBolt("StormBoltA", new StormMultipleStreamBoltA(), 1).shuffleGrouping(
				"StormBolt","stream2");

		builder.setBolt("StormBoltB", new StormMultipleStreamBoltB(), 1).shuffleGrouping(
				"StormBolt","stream1");


		Config conf = new Config();
		conf.setDebug(false);
		// create an instance of LocalCluster class for
		// executing topology in local mode.
		LocalCluster cluster = new LocalCluster();

		// StormTopolgy is the name of submitted topology.
		cluster.submitTopology("StormToplogy", conf, builder.createTopology());
		try {
			Thread.sleep(10000);
		} catch (Exception exception) {
			System.out.println("Thread interrupted exception : " + exception);
		}
		// kill the LearningStormTopology
		cluster.killTopology("StormToplogy");
		// shutdown the storm test cluster
		cluster.shutdown();

	}
}
