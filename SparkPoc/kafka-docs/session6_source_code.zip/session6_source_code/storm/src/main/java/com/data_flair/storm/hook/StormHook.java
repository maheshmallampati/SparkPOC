package com.data_flair.storm.hook;

import java.util.Map;

import backtype.storm.hooks.BaseTaskHook;
import backtype.storm.hooks.info.EmitInfo;
import backtype.storm.hooks.info.SpoutAckInfo;
import backtype.storm.task.TopologyContext;

public class StormHook extends BaseTaskHook {

	@Override
	public void prepare(Map conf, TopologyContext context) {
		// initialize the connection with external reporting tools:
	}
	@Override
	public void emit(EmitInfo info) {
		System.out.println("Hook Tuple: "+info.values);
	}

}
