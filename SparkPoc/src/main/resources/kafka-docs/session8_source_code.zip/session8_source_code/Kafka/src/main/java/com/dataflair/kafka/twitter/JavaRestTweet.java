package com.dataflair.kafka.twitter;

import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

public class JavaRestTweet {
	static String consumerKeyStr = "c9Am6YTixnVK18TFr1wFskT3q";
	static String consumerSecretStr = "WJ8RDOTonjLREN5IbveX1OP9IfBbmp71HKbqalpizIwwwkBpKC";
	static String accessTokenStr = "2984376068-hHQrsMbFPfE16frABXMcRIn7aUSSnNneMEPrUuZ";
	static String accessTokenSecretStr = "1LMNZZnXbUfydsO6rQdyoIfrAimpD004QilV1pH3PYTvM";

	public static void main(String[] args) throws Exception {

		Twitter twitter = new TwitterFactory().getInstance();

		twitter.setOAuthConsumer(consumerKeyStr, consumerSecretStr);
		AccessToken accessToken = new AccessToken(accessTokenStr,
				accessTokenSecretStr);

		twitter.setOAuthAccessToken(accessToken);

		twitter.updateStatus("Post using Twitter4J Again");
		//System.out.println(twitter.getAvailableTrends());


	}
}
