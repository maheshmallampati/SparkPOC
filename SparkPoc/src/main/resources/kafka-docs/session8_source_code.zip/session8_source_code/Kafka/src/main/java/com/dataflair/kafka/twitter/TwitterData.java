package com.dataflair.kafka.twitter;

import java.util.Properties;

import kafka.javaapi.producer.Producer;
import kafka.producer.KeyedMessage;
import kafka.producer.ProducerConfig;
import twitter4j.StallWarning;
import twitter4j.Status;
import twitter4j.StatusDeletionNotice;
import twitter4j.StatusListener;
import twitter4j.TwitterStream;
import twitter4j.TwitterStreamFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.json.DataObjectFactory;

import com.dataflair.kafka.CreateTopic;

public class TwitterData {

	/** The actual Twitter stream. It's set up to collect raw JSON data */
	private TwitterStream twitterStream;
	static String consumerKeyStr = "c9Am6YTixnVK18TFr1wFskT3q";
	static String consumerSecretStr = "WJ8RDOTonjLREN5IbveX1OP9IfBbmp71HKbqalpizIwwwkBpKC";
	static String accessTokenStr = "2984376068-hHQrsMbFPfE16frABXMcRIn7aUSSnNneMEPrUuZ";
	static String accessTokenSecretStr = "1LMNZZnXbUfydsO6rQdyoIfrAimpD004QilV1pH3PYTvM";

	public void start() {
		ConfigurationBuilder cb = new ConfigurationBuilder();
		cb.setOAuthConsumerKey(consumerKeyStr);
		cb.setOAuthConsumerSecret(consumerSecretStr);
		cb.setOAuthAccessToken(accessTokenStr);
		cb.setOAuthAccessTokenSecret(accessTokenSecretStr);
		cb.setJSONStoreEnabled(true);
		cb.setIncludeEntitiesEnabled(true);
		// instance of TwitterStreamFactory
		twitterStream = new TwitterStreamFactory(cb.build()).getInstance();

		// kafka producer api
		final Producer<String, String> producer = new Producer<String, String>(
				getProducerConfig());
		// topicDetails
		new CreateTopic("127.0.0.1:2181").createTopic("twitterData", 2, 1);

		/** Twitter listener **/
		StatusListener listener = new StatusListener() {
			public void onStatus(Status status) {
				KeyedMessage<String, String> data = new KeyedMessage<String, String>(
						"twitterData", DataObjectFactory.getRawJSON(status));
				// send the data to kafka
				producer.send(data);

			System.out.println("TWEET : "+ DataObjectFactory.getRawJSON(status));

			}

			public void onException(Exception arg0) {
				System.out.println(arg0);
			}

			public void onDeletionNotice(StatusDeletionNotice arg0) {
			}

			public void onScrubGeo(long arg0, long arg1) {
			}

			public void onStallWarning(StallWarning arg0) {
			}

			public void onTrackLimitationNotice(int arg0) {
			}
		};

		/** Bind the listener **/
		twitterStream.addListener(listener);

		/** GOGOGO **/
		twitterStream.sample();
	}

	private ProducerConfig getProducerConfig() {

		// Build the configuration required for connecting to Kafka
		Properties props = new Properties();

		// List of Kafka brokers. Complete list of brokers is not
		// required as the producer will auto discover the rest of
		// the brokers. Change this to suit your deployment.
		props.put("metadata.broker.list", "localhost:9092");

		// Serializer used for sending data to kafka. Since we are sending
		// string,
		// we are using StringEncoder.
		props.put("serializer.class", "kafka.serializer.StringEncoder");

		// We want acks from Kafka that messages are properly received.
		props.put("request.required.acks", "1");

		// Create the producer instance
		ProducerConfig config = new ProducerConfig(props);
		return config;

	}

	public static void main(String[] args) throws InterruptedException {
		new TwitterData().start();
	}

}
