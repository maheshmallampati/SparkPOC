package com.data_flair.storm;

import backtype.storm.Config;
import backtype.storm.LocalCluster;
import backtype.storm.topology.TopologyBuilder;

public class WordCountTopology {

	public static void main(String[] args) throws Exception{
		Config config = new Config();
		config.put("inputFile", "/home/centos/Desktop/TextData");
		config.setDebug(false);

		TopologyBuilder builder = new TopologyBuilder();
		builder.setSpout("file-reader-spout", new WorldCountSpout(),2);
		builder.setBolt("word-spitter", new WordSpitterBolt(),2).shuffleGrouping("file-reader-spout");
		builder.setBolt("word-counter", new CountBolt()).shuffleGrouping("word-spitter");

		LocalCluster cluster = new LocalCluster();
		cluster.submitTopology("HelloStorm", config, builder.createTopology());
		Thread.sleep(10000);

		cluster.shutdown();
	}

}

